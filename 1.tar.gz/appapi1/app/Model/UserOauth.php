<?php
namespace App\Model;

class UserOauth extends Model
{
    protected $table = 'user_oauth';
    const CREATED_AT = 'created_at';
    const UPDATED_AT = 'updated_at';
}