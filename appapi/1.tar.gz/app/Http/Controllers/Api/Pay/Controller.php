<?php
namespace App\Http\Controllers\Api\Pay;

use App\Http\Controllers\Api\AuthController as BaseController;
use App\Exceptions\ApiException;

class Controller extends BaseController {

}