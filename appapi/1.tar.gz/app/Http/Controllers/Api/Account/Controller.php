<?php
namespace App\Http\Controllers\Api\Account;

use App\Http\Controllers\Api\Controller as BaseController;

abstract class Controller extends BaseController {

}