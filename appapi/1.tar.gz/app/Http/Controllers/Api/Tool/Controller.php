<?php
namespace App\Http\Controllers\Api\Tool;

use Illuminate\Http\Request;
use App\Exceptions\ApiException;
use App\Parameter;
use App\Http\Controllers\Api\Controller as BaseController;

class Controller extends BaseController
{

}