<?php
namespace App\Model;

class ForceCloseIaps extends Model
{
    protected $table = 'force_close_iaps';
    protected $primaryKey = 'id';
}