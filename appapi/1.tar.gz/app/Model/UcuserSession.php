<?php
namespace App\Model;

class UcuserSession extends Model
{
	protected $table = 'ucuser_session';

	const CREATED_AT = 'created_at';
    const UPDATED_AT = 'updated_at';
}