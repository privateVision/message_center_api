<?php
namespace App\Model;

class YunpianCallback extends Model
{
	protected $table = 'yunpian_callback';
	const CREATED_AT = 'created_at';
	const UPDATED_AT = 'updated_at';
}