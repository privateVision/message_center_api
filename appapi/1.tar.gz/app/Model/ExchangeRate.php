<?php
namespace App\Model;

class ExchangeRate extends Model
{
    protected $table = 'exchange_rate';
    protected $primaryKey = 'id';
}