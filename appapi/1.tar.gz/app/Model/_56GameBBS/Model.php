<?php
namespace App\Model\_56GameBBS;

use Illuminate\Database\Eloquent\Model as Eloquent;

abstract class Model extends Eloquent
{
    protected $connection = '56gamebbs';

    const CREATED_AT = null;
    const UPDATED_AT = null;
}