<?php
namespace App\Model\_56GameBBS;

class Members extends Model
{
    protected $table = 'members';
    protected $primaryKey = 'uid';
}