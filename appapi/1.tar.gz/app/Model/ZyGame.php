<?php
namespace App\Model;

class ZyGame extends Model
{
    protected $table = 'zy_game';
    protected $primaryKey = 'id';
}