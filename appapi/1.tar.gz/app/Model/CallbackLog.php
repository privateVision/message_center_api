<?php
namespace App\Model;

class CallbackLog extends Model {
    protected $table = 'callback_log';
    protected $primaryKey = 'id';
}