<?php
namespace App\Model;

class OrdersExt extends Model
{

	protected $table = 'ordersExt';
	protected $primaryKey = 'oid';
	public $incrementing = false;
}