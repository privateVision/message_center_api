<?php
namespace App\Model\MongoDB;

class UsersMessage extends Model
{
    protected $collection = 'sdk_api_users_message';
}