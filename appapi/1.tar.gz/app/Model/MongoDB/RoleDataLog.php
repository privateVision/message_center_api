<?php
namespace App\Model\MongoDB;

class RoleDataLog extends Model{

    protected $collection = "sdk_roledatas";
    const CREATED_AT = null;
    const UPDATED_AT = null;
}