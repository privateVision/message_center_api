<?php
namespace App\Model\MongoDB;

class UserMessage extends Model
{
    protected $collection = 'sdk_api_user_message';
}