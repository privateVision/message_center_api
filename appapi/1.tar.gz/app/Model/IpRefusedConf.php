<?php

namespace App\Model;

class IpRefusedConf extends Model
{
    protected $table = 'iprefused_conf';
}
