<?php

namespace App\Model;

class IpRefusedConf extends Model
{
    protected $table = 'anfan_iprefused_conf';
}
