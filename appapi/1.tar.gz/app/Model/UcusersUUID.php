<?php
namespace App\Model;

class UcusersUUID extends Model
{
	protected $table = 'ucusers_uuid';
	protected $primaryKey = 'uuid';
	public $incrementing = false;
}