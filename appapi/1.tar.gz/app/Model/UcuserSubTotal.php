<?php
namespace  App\Model;

class UcuserSubTotal extends Model{

    protected $table = 'ucuser_sub_total';
    protected $primaryKey = 'id';
    public $incrementing = false;

    const CREATED_AT = null;
    const UPDATED_AT = null;
}
