<?php
/**
 * Created by PhpStorm.
 * Ucuser: Administrator
 * Date: 2017/3/21
 * Time: 19:26
 */

namespace App\Model;
class IosReceiptLog extends Model {

    protected $table = 'ios_receipt_log';
    protected $primaryKey = 'id';

    const CREATED_AT = null;
    const UPDATED_AT = null;

}
