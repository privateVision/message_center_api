<?php
namespace App\Model;

class ProceduresProducts extends Model
{
	protected $table = 'procedures_products';
	protected $primaryKey = 'id';
	protected static $_instances = [];
}