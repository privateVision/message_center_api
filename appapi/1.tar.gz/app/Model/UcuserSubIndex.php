<?php
namespace  App\Model;

class UcuserSubIndex extends Model{

    protected $table = 'ucuser_sub_index';
    protected $primaryKey = 'id';

    const CREATED_AT = null;
    const UPDATED_AT = null;
}
