<?php
namespace App\Model;

class LoginLog extends Model
{
    protected $table = 'login_log_161013';
    protected $primaryKey = 'id';
}
