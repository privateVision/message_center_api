<?php
namespace App\Model;

class LoginLog extends Model
{
    protected $table = 'login_log';
    protected $primaryKey = 'id';
}