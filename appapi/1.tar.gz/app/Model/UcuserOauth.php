<?php
namespace App\Model;

class UcuserOauth extends Model
{
    protected $table = 'ucuser_oauth';
    const CREATED_AT = 'created_at';
    const UPDATED_AT = 'updated_at';
}