<?php
namespace App\Model\Log;

class DeviceApps extends Model {

    protected $collection = "device_apps_log";
}