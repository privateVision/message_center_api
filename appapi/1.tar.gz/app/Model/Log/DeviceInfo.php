<?php
namespace App\Model\Log;

class DeviceInfo extends Model {
    protected $collection = "device_info_log";
}