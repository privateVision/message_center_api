<?php
namespace App\Model\Log;

class UserEventLog extends Model {

    protected $collection = "user_event_log";
}