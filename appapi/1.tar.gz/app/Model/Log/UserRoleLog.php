<?php
namespace App\Model\Log;

class UserRoleLog extends Model{

    protected $collection = "user_role_log";

    const CREATED_AT = null;
    const UPDATED_AT = null;
}