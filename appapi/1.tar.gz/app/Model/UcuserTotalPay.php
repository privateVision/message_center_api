<?php
namespace App\Model;

class UcuserTotalPay extends Model
{
    protected $table = 'ucuser_total_pay';
    protected $primaryKey = 'ucid';
    public $incrementing = false;
}