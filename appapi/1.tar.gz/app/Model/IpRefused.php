<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2017/5/19
 * Time: 9:29
 */

namespace App\Model;

class IpRefused extends Model
{
    protected $table = 'iprefused';
    protected $primaryKey = 'id';
}