<?php
namespace App\Model;

class Retailers extends Model
{
    protected $table = 'retailers';
    protected $primaryKey = 'rid';
}