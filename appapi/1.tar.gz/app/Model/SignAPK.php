<?php
namespace App\Model;

class SignAPK extends Model
{
	protected $table = 'signapk';
}