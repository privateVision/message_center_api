<?php
namespace App\Model;

class UcusersVC extends Model
{
    protected $table = 'ucusersVC';
}