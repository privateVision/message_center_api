<?php
/**
 * Created by PhpStorm.
 * Ucuser: Administrator
 * Date: 2017/3/21
 * Time: 17:16
 */
namespace  App\Model;
class IosOrderExt extends Model{

    protected $table = 'ios_order_ext';
    protected $primaryKey = 'oid';

    const CREATED_AT = null;
    const UPDATED_AT = null;



}
